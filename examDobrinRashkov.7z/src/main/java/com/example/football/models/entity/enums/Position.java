package com.example.football.models.entity.enums;

public enum Position {
    ATT,MID,DEF
}
